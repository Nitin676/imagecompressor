import React from "react";

import ImageCompressor from "./components/ImageCompressor";

const App = () => <ImageCompressor />;

export default App;
